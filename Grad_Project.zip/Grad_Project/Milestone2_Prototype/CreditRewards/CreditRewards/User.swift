//
//  User.swift
//  CreditRewards
//
//  Created by Christina Nguyen on 10/22/16.
//  Copyright © 2016 Christina Nguyen. All rights reserved.
//

import Foundation

class User {
    
    var score: Int?
    var cards: Int?
    var ftf: Bool?
    var af: Bool?
    var balanceXfer: Bool?
    var forex: Bool?
    var rewardT: Int?

}